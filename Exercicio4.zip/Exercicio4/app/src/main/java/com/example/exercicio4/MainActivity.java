package com.example.exercicio4;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText edtConsumo, edtCouvert, edtPessoas;
    private EditText edtTaxa, edtTotal, edtValorPessoa;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edtConsumo = findViewById(R.id.edtConsumo);
        edtCouvert = findViewById(R.id.edtCouvert);
        edtPessoas = findViewById(R.id.edtPessoas);
        edtTaxa = findViewById(R.id.edtTaxa);
        edtTotal = findViewById(R.id.edtTotal);
        edtValorPessoa = findViewById(R.id.edtValorPessoa);
        button = findViewById(R.id.button);

        button.setOnClickListener(view -> calcularConta());
    } // <-- fim do onCreate

    private void calcularConta() {
        double consumo = lerValor(edtConsumo);
        double couvert = lerValor(edtCouvert);
        int pessoas = (int) lerValor(edtPessoas);

        if (pessoas <= 0) {
            Toast.makeText(this, "Informe quantas pessoas vão dividir a conta", Toast.LENGTH_SHORT).show();
            return;
        }

        double taxaServico = consumo * 0.10;
        double contaTotal = consumo + couvert + taxaServico;
        double valorPorPessoa = contaTotal / pessoas;

        edtTaxa.setText(String.format(Locale.getDefault(), "R$ %.2f", taxaServico));
        edtTotal.setText(String.format(Locale.getDefault(), "R$ %.2f", contaTotal));
        edtValorPessoa.setText(String.format(Locale.getDefault(), "R$ %.2f", valorPorPessoa));
    }

    private double lerValor(EditText campo) {
        String texto = campo.getText().toString().trim();
        if (texto.isEmpty()) return 0;
        try {
            return Double.parseDouble(texto);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}