package com.example.layout_ex02transito;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pergunta1 extends AppCompatActivity {

    Button btnResposta1;
    Button btnResposta2;
    Button btnResposta3;
    Button btnResposta4;
    Button btnProxima;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pergunta1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Ligando os botões do XML ao Java
        btnResposta1 = findViewById(R.id.btnResposta1);
        btnResposta2 = findViewById(R.id.btnResposta2);
        btnResposta3 = findViewById(R.id.btnResposta3);
        btnResposta4 = findViewById(R.id.btnResposta4);
        btnProxima = findViewById(R.id.btnProxima);

        // O botão próxima começa desabilitado
        btnProxima.setEnabled(false);

        // Resposta 1 - ERRADA
        btnResposta1.setOnClickListener(v -> {

            Quiz.salvarResultado(this, 1, false);

            btnProxima.setEnabled(true);
        });

        // Resposta 2 - CORRETA
        btnResposta2.setOnClickListener(v -> {

            Quiz.salvarResultado(this, 1, true);

            btnProxima.setEnabled(true);
        });

        // Resposta 3 - ERRADA
        btnResposta3.setOnClickListener(v -> {

            Quiz.salvarResultado(this, 1, false);

            btnProxima.setEnabled(true);
        });

        // Resposta 4 - ERRADA
        btnResposta4.setOnClickListener(v -> {

            Quiz.salvarResultado(this, 1, false);

            btnProxima.setEnabled(true);
        });

        // Próxima pergunta
        btnProxima.setOnClickListener(v -> {

            Intent intent = new Intent(Pergunta1.this, Pergunta2.class);
            startActivity(intent);

            finish();
        });
    }
}
