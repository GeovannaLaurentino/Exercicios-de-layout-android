package com.example.layout_ex02transito;

import android.content.Context;
import android.content.SharedPreferences;

public class Quiz {

    private static final String PREFS = "quiz_resultado";

    public static void salvarResultado(Context context, int pergunta, boolean acertou) {

        SharedPreferences prefs =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        prefs.edit()
                .putBoolean("pergunta" + pergunta, acertou)
                .apply();
    }

    public static boolean acertou(Context context, int pergunta) {

        SharedPreferences prefs =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        return prefs.getBoolean("pergunta" + pergunta, false);
    }

    public static int getAcertos(Context context) {

        int acertos = 0;

        for (int i = 1; i <= 5; i++) {

            if (acertou(context, i)) {
                acertos++;
            }
        }

        return acertos;
    }

    public static int getErros(Context context) {

        return 5 - getAcertos(context);
    }

    public static void limparResultado(Context context) {

        SharedPreferences prefs =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        prefs.edit().clear().apply();
    }
}