package com.example.layout_ex02transito;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Ranking extends AppCompatActivity {

    Button btnAcertos;
    Button btnErros;


    Button btnPergunta1;
    Button btnPergunta2;
    Button btnPergunta3;
    Button btnPergunta4;
    Button btnPergunta5;
    Button btnVoltar, btnEncerrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ranking);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Ligando os botões do XML
        btnAcertos = findViewById(R.id.btnAcertos);
        btnErros = findViewById(R.id.btnErros);

        btnPergunta1 = findViewById(R.id.btnPergunta1);
        btnPergunta2 = findViewById(R.id.btnPergunta2);
        btnPergunta3 = findViewById(R.id.btnPergunta3);
        btnPergunta4 = findViewById(R.id.btnPergunta4);
        btnPergunta5 = findViewById(R.id.btnPergunta5);

        btnVoltar = findViewById(R.id.btnVoltar);
        btnEncerrar = findViewById(R.id.btnEncerrar);

        // Calcula os acertos e erros
        int acertos = Quiz.getAcertos(this);
        int erros = Quiz.getErros(this);

        // Mostra a quantidade
        btnAcertos.setText("✓  Acertos: " + acertos);
        btnErros.setText("✕  Erros: " + erros);

        // Mostra o resultado de cada pergunta
        mostrarResultado(btnPergunta1, 1);
        mostrarResultado(btnPergunta2, 2);
        mostrarResultado(btnPergunta3, 3);
        mostrarResultado(btnPergunta4, 4);
        mostrarResultado(btnPergunta5, 5);

        // Voltar para o início
        btnVoltar.setOnClickListener(v -> {

            // Limpa o resultado do quiz anterior
            Quiz.limparResultado(this);

            Intent intent = new Intent(Ranking.this, inicio.class);
            startActivity(intent);

            finish();
        });

        btnEncerrar.setOnClickListener(v -> {

            Intent intent = new Intent(Ranking.this, Final.class);
            startActivity(intent);

            finish();
        });

    }

    private void mostrarResultado(Button botao, int pergunta) {

        boolean acertou = Quiz.acertou(this, pergunta);

        if (acertou) {

            botao.setText("✓  Questão 0" + pergunta + " - Acertou");

            botao.setBackgroundTintList(
                    ColorStateList.valueOf(Color.rgb(44, 197, 44))
            );

            botao.setTextColor(Color.BLACK);

        } else {

            botao.setText("✕  Questão 0" + pergunta + " - Errou");

            botao.setBackgroundTintList(
                    ColorStateList.valueOf(Color.rgb(229, 57, 53))
            );

            botao.setTextColor(Color.WHITE);
        }
    }
}