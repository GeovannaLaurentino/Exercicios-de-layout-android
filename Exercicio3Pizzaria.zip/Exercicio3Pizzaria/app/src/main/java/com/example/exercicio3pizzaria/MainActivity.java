package com.example.exercicio3pizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText qtdCalabresa, qtdFrango, qtdMussarela, qtdDoce;
    private Button btnFazerPedido;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.qtdCalabresa), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        qtdCalabresa = findViewById(R.id.qtdCalabresa);
        qtdFrango = findViewById(R.id.qtdFrango);
        qtdMussarela = findViewById(R.id.qtdMussarela);
        qtdDoce = findViewById(R.id.qtdDoce);
        btnFazerPedido = findViewById(R.id.btnFazerPedido);

        btnFazerPedido.setOnClickListener(view -> {
            double total = 0;

            total += calcularSubtotal(qtdCalabresa, 40.00);
            total += calcularSubtotal(qtdFrango, 45.00);
            total += calcularSubtotal(qtdMussarela, 40.00);
            total += calcularSubtotal(qtdDoce, 45.00);

            Intent i = new Intent(this, Total.class);
            i.putExtra("total", total);
            startActivity(i);
        });

    }
    private double calcularSubtotal(EditText campoQtd, double preco) {
        String texto = campoQtd.getText().toString().trim();
        if (texto.isEmpty()) return 0;
        try {
            int quantidade = Integer.parseInt(texto);
            return quantidade * preco;
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}